# MurrHub prototype

Static clickable prototype. No build, no server, no install.

## Open

Open `index.html` in a browser. The phone works from the file itself.

Open `flows.html` for the client and master flow map. Every step links to a screen.

## Controls

Outside the phone: **Клиент / Мастер**, a **Шоколад** slider for the light theme, **Тёмная / Светлая**, **Начать с начала**, and a reset. The same theme switch is on the flow map. The UI copy is Russian. The sample city is Vilnius.

The light theme opens on chocolate. The slider moves it from pale sand to a deeper chocolate. Dark theme stays warm near-black. Type is Nunito Sans for text and Nunito for titles. **Начать с начала** plays the paw icon, then asks gender and age, then interests, the feed, and the first-visit sheet.

## In this version

Gender and age, then interests with craft icons, then the feed as home. A first-visit sheet can stay on the feed or jump to search. Search and map stay in the app. Feed cards do not show price. Posts can be text. Ordinary people post only inside a craft, and a photo still needs the 2€ access. Work posts, master profile, booking, chat, reviews, and the separate master subscription gate.

## Not in this version

No salon page. No life-post composer. No commission and no in-app checkout — those are marked on the master “later” screen, not designed as payment.
